
app_name = "permission_cloner"
app_title = "Permission Cloner"
app_publisher = "Your Name"
app_description = "Tool to copy role permissions from one role to another"
app_email = "your@email.com"
app_license = "MIT"

doctype_js = {
    "Permission Cloner": "public/js/permission_cloner.js"
}
